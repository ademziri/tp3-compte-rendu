package tp3poo;

public class calcul {

	public static void main(String[] args) {
System.out.println("factoriel: " + entier.factoriel(5));

entier.comparer(7, 5);
entier.premier(11);
		
	}

}
