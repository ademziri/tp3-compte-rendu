package tp3poo;

public class entier {
	
static int factoriel(int n) {
	int i;
	int s=1;
	for(i=2;i<=n;i++) {
		s=s*i;
	}
	return s;
}
static void absolu(int n) {
	if(n<0) {
	int s=n*-1;
	System.out.println("valeur absolu egale"+s);}
	else {
		System.out.println("valeur absolu egale"+n);
	}
}
static void comparer(int e1,int e2) {
	if(e1>e2) {
		System.out.println(e1+" est superieur a "+e2);
	}
	else if(e1>e2) {
		System.out.println(e1+" est inferieur a "+e2);
	}
	else {
		System.out.println(e1+" egale a "+e2);
	}
}

static void premier(int n) {
    if (n<= 1) {
    	System.out.println("n'est pas un nombre premier");
        return;
    }
    for (int i=2; i<=n; i++) {
        if (n%i==0) {
            System.out.println("le nombre est pas premier");
            return;
        }
    }
    
    System.out.println("le nombre est premier");
}

}


