package tp32poo;

public class mainmaison {

	public static void main(String[] args) {
maison m1=new maison("tunis","duplex",4,210);
maison m2=new maison("nabeul","villa",5);
m1.tochaine();
m2.tochaine();
m2.setsurface(230);
float a= m2.calculprx();
float e=m1.calculprx(556);

System.out.println("prix maison 1"+a);
System.out.println("prix maison 2"+e);

	}

}
