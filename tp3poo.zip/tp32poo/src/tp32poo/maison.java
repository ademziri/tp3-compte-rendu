package tp32poo;

public class maison {
private String type;
private String adr;
private int nbchambre;
private float surface;


public maison(String adresse,String t,int n) {
	adresse=adr;
	t=type;
	n=nbchambre;
}
public maison(String a,String t,int n,float s) {
	a=adr;
	t=type;
	n=nbchambre;
	s=surface;
}
public void setsurface(float s){
	s=surface;
}
float calculprx(float pmc){
	return(pmc*surface);
}
 float calculprx() {
	return(2100*surface);
}
 
public void tochaine() {
	System.out.println("un "+type+" de "+surface+" a "+adr+" avec "+nbchambre+" chambres");
}



}
