package tp31poo;

public class compte {
private static int compteur=1;
private int numero;
private int solde;

public compte() {
	this.numero=compteur++;
	this.solde=0;
}
public void deposer(int m ) {
	if(m>0) {
		this.solde+=m;
		System.out.println("depot de "+m+"effectue nouveau solde" +this.solde );
	}
	else {
		System.out.println("il faut etre positive");}}
	
public void retirer(int m) {
	if(m>0 && m <= this.solde) {
		System.out.println("retrait "+m+" effectue nouvaur solde"+ this.solde);
		
	}
	else {
		System.out.println("montant insuffisant");
	}

}
public int avoirsolde() {
	return this.solde;
}
public void transferer(int m, compte c) {
	if (m>0 && m<= this.solde) {
		this.retirer(m);
		c.deposer(m);
		System.out.println("transfert de "+m+"vers compte "+c.numero+" effectué");
		
	}
	else {
		System.out.println("transfert impossible solde insifusant");
	}
	
	
}

}
