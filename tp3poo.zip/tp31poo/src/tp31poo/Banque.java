package tp31poo;

public class Banque {

	public static void main(String[] args) {
		compte co1=new compte();
		compte co2=new compte();
co1.deposer(1200);
co2.deposer(500);
System.out.println("solde compte 1" + co1.avoirsolde());
System.out.println("solde compte 2" + co2.avoirsolde());

co2.transferer(700, co1);
System.out.println("solde compte 1 apres transfert " + co2.avoirsolde());
System.out.println("solde compte 2" + co1.avoirsolde());
	}

}
